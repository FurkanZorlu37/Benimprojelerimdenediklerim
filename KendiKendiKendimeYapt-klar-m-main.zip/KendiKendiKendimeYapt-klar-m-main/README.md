c#Derinlemesine 101 Kursunun ilk kısmından ögrendigim kadarıyla c# form uygulaması yapmayı denedim.
Bu benim ilk c# projem olmasından dolayı birsürü eksigi oldugundan eminim.
int i nasıl kulanıcıya sağlıyabilirim onu bile bulamadım mesela :D
